<?php

    define("BASE_URL", "/stitch_version");


?>