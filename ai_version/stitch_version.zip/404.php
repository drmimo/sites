<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>No Result</title>
</head>
<body>
    <h1>
        Here is a closed way, it is better to go back home. <a href="./index.php">[Home]</a>
    </h1>
</body>
</html>